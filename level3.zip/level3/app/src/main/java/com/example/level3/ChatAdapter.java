package com.example.level3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {
    //监听器
    public interface OnItemClickListener{
        void onItemClick(ChatData data);
    }
    public void setOnItemClickListener(OnItemClickListener listener){
        this.listener = listener;
    }


    private OnItemClickListener listener;
    private ArrayList<ChatData> dataList;
    public ChatAdapter(ArrayList<ChatData> dataList) {
        this.dataList = dataList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//创建ViewHolder，为Rv提供⼀个item模板
        View view =
                LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_card,
                        parent, false);
        return new ViewHolder(view);
    }
    //对ViewHolder中初始化好的控件进⾏数据绑定
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(dataList.get(position));
    }
    //需要⽣成的item的数量
    @Override
    public int getItemCount() {
        return dataList.size();
    }
// ViewHolder类
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mChatTitle;
        TextView mChatContent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mChatTitle = itemView.findViewById(R.id.chat_title);
            mChatContent = itemView.findViewById(R.id.chat_content);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getBindingAdapterPosition();
                    ChatData data = dataList.get(pos);
                    listener.onItemClick(data);
                }
            });
        }
        //封装数据绑定逻辑
        public void bind(ChatData data){
            mChatTitle.setText(data.getChatName());
            mChatContent.setText(data.getChatContent());
        }
    }
}
