package com.example.level3;

public class ChatData {
    private String chatName;
    private String chatContent;

    public ChatData(String chatName,String chatContent){
        this.chatName=chatName;
        this.chatContent=chatContent;
    }

    public String getChatName() {
        return chatName;
    }

    public void setChatName(String chatName) {
        this.chatName = chatName;
    }

    public String getChatContent() {
        return chatContent;
    }

    public void setChatContent(String chatContent) {
        this.chatContent = chatContent;
    }
}
