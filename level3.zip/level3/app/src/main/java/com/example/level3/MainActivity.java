package com.example.level3;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initRv();
    }
    private void initRv(){
        mRv = findViewById(R.id.chat_main);
//设置Adapter
        ChatAdapter adapter = new ChatAdapter(getChatData());
        mRv.setAdapter(adapter);
//设置布局管理器LayoutManager
        mRv.setLayoutManager(new LinearLayoutManager(this));

        adapter.setOnItemClickListener(data -> Toast.makeText(MainActivity.this,data.getChatName(),Toast.LENGTH_SHORT).show());
    }
    private ArrayList<ChatData> getChatData(){
        ArrayList<ChatData> dataList=new ArrayList<>();
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));
        dataList.add(new ChatData("自定义名称1","嗨嗨嗨"));

        return dataList;
    }
}

